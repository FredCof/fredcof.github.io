var tobox = new Boolean(0);
var boxed = new Boolean(0);
var targed = new Boolean(1);
var moving = new Boolean(0);
var down = 0;
//var taging = new Boolean(0);
var count = 0;
var Xstar = 0;
var Ystar = 0;
var textJson = "";
var tempID = "";

//reset除count以外的参数，需要在图片完成标记才可以调用
function reset(){
    tobox = new Boolean(0);
    boxed = new Boolean(0);
    targed = new Boolean(1);
    down = 0;
    Xstar = 0;
    Ystar = 0;
    tempID = "";
    moving = new Boolean(0);
}


function submittag(){
    ;
}

//检查在图像标签以内
function imgIn(X,Y){
    var tag = 0;
    var imgtop = $('#rightclick').offset().top;
    var imgleft = $('#rightclick').offset().left;
    var imgbottom = imgtop + 960;
    var imgright = imgleft + 1280;
    if(Y < imgtop){ tag = tag | 1;}
    if(Y > imgbottom){tag = tag | 2;}
    if(X < imgleft){tag = tag | 4;}
    if(X > imgright){tag = tag | 8;}
    /*  右边超出返回1000
        左边超出返回0100
        下边超出返回0010
        上边超出返回0001    */
    $("#test").html("MouseX: "+X+"<br/>MouseY: "+Y+"<br/>Tag: "+tag+
                    "<br/><br/>ImageTop: "+imgtop+"<br/>ImageBottom: "+imgbottom+"<br/>ImageLeft: "+imgleft+"<br/>ImageRight: "+imgright+
                    "<br/><br/>Tag&: "+(tag & 1)+"  "+(tag & 2)+"  "+(tag & 4)+"  "+(tag & 8)+
                    "<br/><br/>Down: "+down+
                    "<br/><br/>tempID: "+tempID+
                    "<br/>moving: "+moving);
    return tag;
}

function moveCross(X,Y){
    var tag = imgIn(X,Y);
    var tagX = X - $('#rightclick').offset().left;
    var tagY = Y - $('#rightclick').offset().top;
    if((tag & 1) == 1){ tagY = 0;}
    if((tag & 2) == 2){ tagY = 960;}
    if((tag & 4) == 4){ tagX = 0;}
    if((tag & 8) == 8){ tagX = 1280;}
    $("#horizon").css("top",tagY);
    $("#vertical").css("left",tagX);
}

//右键菜单消失
function hideRight(){
    $("#rightMenu").addClass("noplay");
}

//标记菜单消失,改变当前div颜色
function hideCreate(){
    targed = new Boolean(1);
    $("#createMenu").addClass("noplay");
    $("#"+(count - 1)).addClass("objectboxafter");
    hideRight();
}

//box操作菜单隐藏
function hideBoxmenu(){
    $("#boxMenu").addClass("noplay");
    tempID = "";
}

$("body").mousedown(function(event){
    if($(event.target).hasClass("objectbox") & targed){
        if(moving == true){
            moving = new Boolean(0);
        }else{
            tempID = $(event.target).attr("id");
            $("#boxMenu").removeClass("noplay");
            $("#boxMenu").css({"left" : event.pageX - 5, "top" : event.pageY - 15});
        }
    }else{
        if( ($(event.target).attr("id") == count - 1) ){
            if($(event.target).hasClass("objectboxafter")){}else{
                $(event.target).remove();
                hideCreate();
                count--;
            }
        }
    }
    if ( $(event.target).hasClass("rightclick")){
        if($("#createMenu").hasClass("noplay")){
            if((event.which == 3) & targed){
                $("#rightMenu").removeClass("noplay");
                $("#rightMenu").css({"left" : event.pageX - 5, "top" : event.pageY - 15});
                hideBoxmenu();
            }else if(event.which == 1){
                hideRight();
                hideBoxmenu();
            }//中键2 左键1
        }else{
            alert("请务必打上标签！");
        }
    }else{
        hideRight();
        if($("#createMenu").hasClass("noplay")){
            if($(event.target).children().hasClass("glyphicon-screenshot") || $(event.target).siblings().hasClass("glyphicon-screenshot")){
                tobox = new Boolean(1);
                down = 0;
                targed = new Boolean(0);
            }else if($(event.target).children().hasClass("glyphicon-tag") || $(event.target).siblings().hasClass("glyphicon-tag")){
                $("#createMenu").removeClass("noplay");
                $("#createMenu").css({"left" : event.pageX - 5, "top" : event.pageY - 15}); 
                hideRight(); 
            }else if($(event.target).children().hasClass("glyphicon-trash") || $(event.target).siblings().hasClass("glyphicon-trash")){
                $("#"+tempID).remove();
                hideBoxmenu();
            }else if($(event.target).children().hasClass("glyphicon-move") || $(event.target).siblings().hasClass("glyphicon-move")){
                moving = new Boolean(1);
                $("#boxMenu").addClass("noplay");
            }else if($(event.target).hasClass("glyphicon-arrow-left")){
                alert("shyizh tupian");
            }else if($(event.target).hasClass("glyphicon-arrow-right")){
                alert("xiayizh");
            }
        }else{
            if ($(event.target).children().hasClass("glyphicon-ok") || $(event.target).siblings().hasClass("glyphicon-ok")){
                if(tempID == ""){
                    $("#"+(count - 1)).addClass("objectperson");
                    $("#"+(count - 1)).html("Person");
                }else{
                    $("#"+tempID).addClass("objectperson");
                    $("#"+tempID).removeClass("objectnot");
                    $("#"+tempID).html("Person");
                }
                hideCreate();
            }else if($(event.target).children().hasClass("glyphicon-remove") || $(event.target).siblings().hasClass("glyphicon-remove")){
                if(tempID == ""){
                    $("#"+(count - 1)).addClass("objectnot");
                    $("#"+(count - 1)).html("Not Person");
                }else{
                    $("#"+tempID).addClass("objectnot");
                    $("#"+tempID).removeClass("objectpreson");
                    $("#"+tempID).html("Not Person");
                }
                hideCreate();
            }else{
                alert("请务必打上标签！");
            }
        }
    }
});

//阻止系统右键菜单
$(document).contextmenu(function(){
    return false;
});

//鼠标up事件监听
$("body").mouseup(function(event){
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    if(tobox){
        down++;
    }
    if(boxed == true){
        $("#createMenu").removeClass("noplay");
        $("#createMenu").css({"left" : event.pageX - 5, "top" : event.pageY - 15});  
        boxed = new Boolean(0);
        boxing = new Boolean(0);
        imgin();
    }else if((tobox == true)&(down == 2)){
        //将要box，Cross展现并且跟随移动
        //此时鼠标up，生成标准div，设置Xstar,Ystar
        //取消tobox，Cross停止跟随并且消失
        $("#horizon").addClass("noplay");
        $("#vertical").addClass("noplay");

        var tag = imgIn(event.pageX,event.pageY);
        Xstar = event.pageX - $('#rightclick').offset().left;
        Ystar = event.pageY - $('#rightclick').offset().top;
        if((tag & 1) == 1){ Ystar = 0;}
        if((tag & 2) == 2){ Ystar = 960;}
        if((tag & 4) == 4){ Xstar = 0;}
        if((tag & 8) == 8){ Xstar = 1280;}
        $("#test").text(Xstar+"  "+Ystar);
        boxed = new Boolean(1);
        tobox = new Boolean(0);

        var box = $("<div></div>");
        box.attr("id",count);
        box.addClass("objectbox");
        box.css({"top" : Ystar, "left" : Xstar});
        $("#img-space").append(box);
        count++;
    }
});

$(document).bind('mousemove',function(event){
    imgIn(event.pageX,event.pageY);
    if(tobox == true){
        //tobox期间控制Cross移动
        var X = event.pageX;
        var Y = event.pageY;
        $("#horizon").removeClass("noplay");
        $("#vertical").removeClass("noplay");
        moveCross(X,Y);
    }else if(boxed == true){
        var tag = imgIn(event.pageX,event.pageY);
        var X = event.pageX - $('#rightclick').offset().left;
        var Y = event.pageY - $('#rightclick').offset().top;
        if((tag & 1) == 1){ Y = 0;}
        if((tag & 2) == 2){ Y = 960;}
        if((tag & 4) == 4){ X = 0;}
        if((tag & 8) == 8){ X = 1280;}
        //box期间改变标准div框
        Y = Y - Ystar;
        X = X - Xstar;
        $("#test").append("<br/><br/>Div:  "+X +"  " +Y+"<br/>ID:"+count);
        $("#"+(count - 1)).css({"height" : Y,"width" : X});
    }else if(moving == true){
        var tag = imgIn(event.pageX,event.pageY);
        var X = event.pageX - $('#rightclick').offset().left;
        var Y = event.pageY - $('#rightclick').offset().top;
        if((tag & 1) == 1){ Y = 0;}
        if((tag & 2) == 2){ Y = 960;}
        if((tag & 4) == 4){ X = 0;}
        if((tag & 8) == 8){ X = 1280;}
        $("#"+tempID).css({"top" : Y,"left" : X});
    }
});