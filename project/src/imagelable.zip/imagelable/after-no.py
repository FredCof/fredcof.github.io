#encoding UTF-8
import pymysql
import json
import sys
import os 

Set_Mothed_VOC = False

imgPath = "./"

pixelHeight = 1.0/960.0
pixelWidth = 1.0/1280.0

conn = pymysql.connect("47.75.190.236","remoteroot","cofalconer&123456","labelimg")
cur = conn.cursor()

def readImg():
    sql = '''SELECT * FROM imginfo where marked=1'''
    cur.execute(sql)
    data = cur.fetchall()
    conn.commit()
    return data

def NormalType(data):
    if not os.path.isdir("./output/"):
        os.makedirs("./output/")
    for item in data:
        with open("./output/%s.txt"%item[0],"a") as outTxt:
            objectTxtList = []
            jsonItem = json.loads(item[4])
            for objectItem in jsonItem['object']:
                objectTxt = ""
                if "person" in objectItem:
                    objectTxt += "1 "
                else:
                    objectTxt += "0 "
                text = [float(i[0:-2]) for i in list(objectItem.values())[0].split('/')]
 
                xCenter = (text[0] + text[3]/2)*pixelWidth
                yCenter = (text[1] + text[2]/2)*pixelWidth
                Width = text[3]*pixelHeight
                Height = text[2]*pixelHeight
                
                objectTxt = objectTxt + "%.10f "%xCenter + "%.10f "%yCenter + "%.10f "%Width + "%.10f"%Height +"\n"
                objectTxtList.append(objectTxt)
            outTxt.writelines(objectTxtList)

def VOCType(data):
    with open("./VOCout.txt","a") as outTxt:
        for item in data:
            objectTxtList = [imgPath+"%s.jpg"%item[0],]
            jsonItem = json.loads(item[4])
            for objectItem in jsonItem['object']:
                objectTxt = ""
                if "person" in objectItem:
                    objectclass = "1"
                else:
                    objectclass = "0"
                text = [float(i[0:-2]) for i in list(objectItem.values())[0].split('/')]

                xmin = int(text[1]/2)
                ymin = int(text[0]/2)
                xmax = int((text[1] + text[3])/2)
                ymax = int((text[0] + text[2])/2)
                
                objectTxt = " %d,"%xmin + "%d,"%ymin + "%d,"%xmax + "%d,"%ymax + objectclass
                objectTxtList.append(objectTxt)
            objectTxtList.append("\n")
            outTxt.writelines(objectTxtList)

def makeTxt(data):
    if Set_Mothed_VOC:
        NormalType(data)
    else:
        VOCType(data)

if __name__ == "__main__":
    #{"object": [{"person": "top/left/height/width"}]}
    data = readImg()
    makeTxt(data)
