<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User face</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="./js/library/jquery-3.4.1.js"></script>
</head>

<body>
<?php
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
    } catch (PDOException $e) {
        echo 'Connection failed: ' . $e->getMessage();
    }
//执行sql语句
    $machine = $_GET["machine"];
    if(strlen($machine) == 0) $machine = "00000001";
    $sql = "select * from product p, productinvmachine piv where p.productNo = piv.productNo and piv.totalnum > 0 and piv.vmachineno = '".$machine."';";
    $pdo->query('set names utf8;');
    $result = $pdo->query($sql);
    $rows = $result->fetchAll();
?>
    <nav class="center">
        <svg t="1576671969221" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
            p-id="16196" width="20" height="20">
            <path
                d="M341.317818 1024h-204.8A136.936727 136.936727 0 0 1 0 887.482182v-204.8a136.936727 136.936727 0 0 1 136.517818-136.564364h204.8a136.936727 136.936727 0 0 1 136.564364 136.564364v204.8A136.936727 136.936727 0 0 1 341.317818 1024z m-204.8-409.6c-37.515636 0-68.235636 30.72-68.235636 68.282182v204.8c0 37.515636 30.72 68.235636 68.235636 68.235636h204.8c37.562182 0 68.282182-30.72 68.282182-68.235636v-204.8c0-37.562182-30.72-68.282182-68.282182-68.282182h-204.8zM887.482182 1024h-204.8a136.936727 136.936727 0 0 1-136.564364-136.517818v-204.8a136.936727 136.936727 0 0 1 136.564364-136.564364h204.8A136.936727 136.936727 0 0 1 1024 682.682182v204.8A136.936727 136.936727 0 0 1 887.482182 1024z m-204.8-409.6c-37.562182 0-68.282182 30.72-68.282182 68.282182v204.8c0 37.515636 30.72 68.235636 68.282182 68.235636h204.8c37.515636 0 68.235636-30.72 68.235636-68.235636v-204.8c0-37.562182-30.72-68.282182-68.235636-68.282182h-204.8z m-341.364364-136.517818h-204.8A136.936727 136.936727 0 0 1 0 341.317818v-204.8A136.936727 136.936727 0 0 1 136.517818 0h204.8a136.936727 136.936727 0 0 1 136.564364 136.517818v204.8a136.936727 136.936727 0 0 1-136.564364 136.564364z m-204.8-409.6c-37.515636 0-68.235636 30.72-68.235636 68.235636v204.8c0 37.562182 30.72 68.282182 68.235636 68.282182h204.8C378.88 409.6 409.6 378.88 409.6 341.317818v-204.8c0-37.515636-30.72-68.235636-68.282182-68.235636h-204.8z m750.964364 409.6h-204.8a136.936727 136.936727 0 0 1-136.564364-136.564364v-204.8A136.936727 136.936727 0 0 1 682.682182 0h204.8A136.936727 136.936727 0 0 1 1024 136.517818v204.8a136.936727 136.936727 0 0 1-136.517818 136.564364z m-204.8-409.6c-37.562182 0-68.282182 30.72-68.282182 68.235636v204.8c0 37.562182 30.72 68.282182 68.282182 68.282182h204.8c37.515636 0 68.235636-30.72 68.235636-68.282182v-204.8c0-37.515636-30.72-68.235636-68.235636-68.235636h-204.8z"
                p-id="16197"></path>
        </svg>
        <div>自动售货机</div>
        <svg t="1576724530390" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
            p-id="1784" width="20" height="20">
            <path
                d="M512.103132 320.120979a106.221743 106.221743 0 1 1-75.507022 31.354611A106.221743 106.221743 0 0 1 512.103132 320.120979m0-63.989002a170.850635 170.850635 0 1 0 120.939214 49.911422A169.570855 169.570855 0 0 0 512.103132 256.131977z"
                fill="#515151" p-id="1785"></path>
            <path
                d="M805.172761 124.314633a407.609942 407.609942 0 0 0-586.139257 0 431.285873 431.285873 0 0 0 0 599.576948L512.103132 1024l293.069629-300.108419a431.285873 431.285873 0 0 0 0-599.576948z m-44.152411 557.344207l-248.917218 255.956007-248.917217-255.956007a365.377201 365.377201 0 0 1 0-508.712565 346.82039 346.82039 0 0 1 497.834435 0 365.377201 365.377201 0 0 1 0 508.712565z"
                fill="#515151" p-id="1786"></path>
        </svg>
    </nav>

    <div class="contain">
        <ul class="productlist">
        <?php
        foreach ($rows as $row) {
        ?>
            <li id="<?=$row["productNo"]?>" class="center"><img src="img/<?=$row["productNo"]?>.jpg" alt="">
                <a href="buy.php?id=<?=$row["productNo"]?>&machine=<?=$machine?>">
                    <div class="btn"><span><?=$row["price"]?></span>购买</div>
                </a>
            </li>    
        <?php
        }
        ?>
        </ul>
        <?php
            $sql = "select vmachineNo from vmachine;";
            $result = $pdo->query($sql);
            $rows = $result->fetchAll();
        ?>
        <div class="choose">
            <select id="machine">
            <?php
                foreach ($rows as $row) {
                    if($row["vmachineNo"] == $machine){
            ?>
                    <option value="<?=$row["vmachineNo"]?>" selected="selected"><?=$row["vmachineNo"]?></option>
            <?php
                }else{
            ?>
                    <option value="<?=$row["vmachineNo"]?>"><?=$row["vmachineNo"]?></option>
            <?php
                }
            }
            ?>
            </select>
        </div>
    </div>

    <script src="./js/personal/aboutme.js"></script>
    <script>
        $('#machine').change(function(){ 
            let machine = $(this).children('option:selected').val();
            $(window).attr('location','./index.php?machine='+machine);
        }) 
    </script>
</body>

</html>