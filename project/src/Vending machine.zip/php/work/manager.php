<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="../js/library/jquery-3.4.1.js"></script>
    <link rel="stylesheet" href="../css/work.css">
</head>

<body>
    <nav>填货管理界面</nav>
    <?php
        function redirect($url)
        {
            header("Location: $url");
            exit();
        }
        if(!$_SESSION["login"]){
            redirect("./index.php");
        }
    ?>
    <?php
        try {
            $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
    //执行sql语句
        $machine = $_GET["machine"];
        
        $id=$_SESSION["id"];
        $sql = "select * from machine where employeeNo = '".$id."';";
        $pdo->query('set names utf8;');
        $result = $pdo->query($sql);
        $machines = $result->fetchAll();

        $flag = false;
        
        foreach ($machines as $mac){
            if($mac["no"] == $machine){
                $flag = true;
            }
        }
 
        if(!$flag){
            $machine = $machines[0]["no"];
        }
        $sql = "select * from piv where vmachineNo = '".$machine."';";
        $result = $pdo->query($sql);
        
        $rows = $result->fetchAll();
    ?>
    <form action="./control/update.php" method="POST">
        <ul class="productlist">
            <input name="machine" type="hidden" value="<?=$machine?>">
            <?php
                foreach ($rows as $row) {
                ?>
            <li id="<?=$row["productNo"]?>" class="center">
                <span><?=$row["name"]?></span><input type="number" name="<?=$row["productNo"]?>" min="1" max="50" step="1">
            </li>
            <?php
                }
            ?>
            <input type="submit" value="提交"> 
        </ul>
        <select id="machine">
            <?php
                foreach ($machines as $mac) {
            ?>
            <option value="<?=$mac["no"]?>"><?=$mac["no"]?></option>
            <?php
                }
            ?>
        </select>
     </form>
     
    <script>
        $('#machine').change(function () {
            let machine = $(this).children('option:selected').val();
            $(window).attr('location', './manager.php?machine=' + machine);
        }) 
    </script>
    
    </body>

</html>