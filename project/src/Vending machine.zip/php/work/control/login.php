<?php
    session_start();
    function redirect($url)
    {
        header("Location: $url");
        exit();
    }

    try {
        $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
    } catch (PDOException $e) {
        echo 'Connection failed: ' . $e->getMessage();
    }
//执行sql语句
    $id = $_POST["id"];
    $password = $_POST["password"];
    $sql = "select * from employee  where employeeNo = '".$id."' and employeepassword = '".$password."';";
    $pdo->query('set names utf8;');
    $result = $pdo->query($sql);
    $rows = $result->fetchAll();
    $row = $rows[0];
    if($row){
        $_SESSION["login"] = true;
        $_SESSION["rank"] = $row["powerNo"];
        $_SESSION["id"] = $row["employeeNo"];
        redirect("../manager.php");
    }else{
        redirect("../");
    }
?>