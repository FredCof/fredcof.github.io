<?php
    session_start();
    function redirect($url)
    {
        header("Location: $url");
        exit();
    }

    if(!$_SESSION["login"]){
        redirect("../index.php");
    }

    try {
        $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
    } catch (PDOException $e) {
        echo 'Connection failed: ' . $e->getMessage();
    }

    $machine = $_POST["machine"];
    if(strlen($machine) == 0) $machine = "AD201812";

    foreach ($_POST as $key => $value) {
        if($key != "machine"){
            $sql = "update productinvmachine set totalNum=totalNum+".$value." where productNo = '".$key."' and VMachineNo = '".$machine."';";
            $pdo->exec($sql);
        }  
    }
    redirect("../manager.php?machine=".$machine);
?>