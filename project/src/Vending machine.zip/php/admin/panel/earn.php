<?php session_start(); ?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../../css/admin.css">
</head>

<body>
    <?php
        function redirect($url)
        {
            header("Location: $url");
            exit();
        }
        if(!$_SESSION["login"] || $_SESSION["rank"] > 1){
            redirect("../index.php");
        }
    ?>
    <?php
        try {
            $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
        $sql = "select * from salen;";
        $pdo->query('set names utf8;');
        $result = $pdo->query($sql);
        $rows = $result->fetchAll();
    ?>
    <table id="earn" class="showlist">
        <thead>
            <td class="id">商品</td>
            <td class="sale">销售额</td>
        </thead>
        <?php
        foreach ($rows as $row) {
        ?>
        <tr>
            <td class="id"><?=$row["productName"]?></td>
            <td class="sale"><?=$row["money"]?>￥</td>
        </tr>
        <?php
        }
        ?>
    </table>
</body>

</html>