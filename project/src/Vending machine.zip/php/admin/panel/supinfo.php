<?php session_start(); ?>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../../css/admin.css">
</head>

<body>
    <?php
        function redirect($url)
        {
            header("Location: $url");
            exit();
        }
        if(!$_SESSION["login"] || $_SESSION["rank"] > 1){
            redirect("../index.php");
        }
    ?>
    <?php
        try {
            $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
        $sql = "select * from sup;";
        $pdo->query('set names utf8;');
        $result = $pdo->query($sql);
        $rows = $result->fetchAll();
    ?>
    <table id="supinfo" class="showlist">
        <thead>
            <td class="id">供应单号</td>
            <td lass="time">供应时间</td>
            <td class="sup">供应商</td>
            <td class="sub">分公司</td>
        </thead>
        <?php
        foreach ($rows as $row) {
        ?>
        <tr>
            <form action="">
                <td class="id"><?=$row["suporderNo"]?></td>
                <td class="time"><?=$row["supTime"]?></td>
                <td class="sup"><?=$row["supName"]?></td>
                <td class="sub"><?=$row["supTo"]?></td>
            </form>
        </tr>
        <?php
        }
        ?>
    </table>
</body>

</html>