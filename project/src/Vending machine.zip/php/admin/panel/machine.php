<?php session_start(); ?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../../css/admin.css">
    <script src="./js/jquery-3.4.1.js"></script>
</head>

<body>
    <?php
        function redirect($url)
        {
            header("Location: $url");
            exit();
        }
        if(!$_SESSION["login"]){
            redirect("../index.php");
        }
    ?>
    <?php
        try {
            $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
        $sql = "select * from machine;";
        $pdo->query('set names utf8;');
        $result = $pdo->query($sql);
        $rows = $result->fetchAll();
    ?>
    <table id="machine" class="showlist">
        <thead>
            <td class="machineid">编号</td>
            <td class="address">地址</td>
            <td lass="manager">管理人员</td>
            <td class="detail">&emsp;&emsp;</td>
            <?php if($_SESSION["rank"] == 1){ ?>
                <td class="submit">&emsp;&emsp;</td>
            <?php } ?>
        </thead>

        <?php
        foreach ($rows as $row) {
        ?>
        <tr>
            <form action="../control/machine.php" method="POST">
                <td class="machineid"><input readonly="readonly" name="id" type="text" value="<?=$row["no"]?>"></td>
                <td class="address"><input name="address" type="text" value="<?=$row["address"]?>"></td>
                <td class="manager"><?=$row["employeeName"]?></td>
                <td class="detail"><a href="../control/detail.php?machine=<?=$row["no"]?>" target="detail" class="look">查看</a></td>
                <?php if($_SESSION["rank"] == 1){ ?>
                <td class="submit">
                    <a href="../control/machine.php?delete=1&id=<?=$row["no"]?>">删除</a>
                    <input type="submit" value="提交">
                </td>
                <?php } ?>
            </form>
        </tr>
        <?php
        }
        ?>
        <tr class="hide">
            <form id="new" action="../control/machine.php" method="POST">
                <td class="machineid"><input name="id" type="text" value=""></td>
                <td class="address"><input name="address" type="text" value=""></td>
                <td class="manager"><input name="manager" type="text" value=""></td>
                <input type="hidden" name="add" value="1">
                <td><input type="submit" value="提交"></td>
            </form>
        </tr>
    </table>
    <?php if($_SESSION["rank"] == 1){ ?>
    <div id="add">
        <svg t="1577030058750" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
                p-id="1126" width="40" height="40">
            <path d="M912 262v500c0 41.3-14.7 76.7-44 106s-64.6 44-106 44H262.1c-41.3 0-76.7-14.7-106-44s-44-64.6-44-106V262c0-41.3 14.7-76.7 44-106s64.6-44 106-44h500c41.3 0 76.7 14.7 106 44 29.2 29.3 43.9 64.7 43.9 106zM778.6 545.4v-66.7c0-9-3.3-16.9-9.9-23.4-6.6-6.6-14.5-9.9-23.4-9.9H578.7V278.6c0-9-3.3-16.9-9.9-23.4-6.6-6.6-14.5-9.9-23.4-9.9h-66.7c-9 0-16.9 3.3-23.4 9.9s-9.9 14.5-9.9 23.4v166.6H278.7c-9 0-16.9 3.3-23.4 9.9-6.6 6.6-9.9 14.5-9.9 23.4v66.7c0 9 3.3 16.9 9.9 23.4 6.6 6.6 14.3 9.9 23.4 9.9h166.7v166.7c0 9 3.3 16.9 9.9 23.4 6.6 6.6 14.3 9.9 23.4 9.9h66.7c9 0 16.9-3.3 23.4-9.9 6.6-6.6 9.9-14.5 9.9-23.4V578.6h166.6c9 0 16.9-3.3 23.4-9.9 6.6-6.6 9.9-14.4 9.9-23.3z" p-id="1127" fill="#13227a"></path>
        </svg>
    </div>
    <?php } ?>
    <div id="detail" class="hide">
        <div id="close">&times;</div>
        <iframe name="detail" src="https://t.bilibili.com/" frameborder="0"></iframe>
    </div>
    <script>
        $("#add").click(function(){
            $("tr.hide").attr("class","");
        });
        $(".look").click(function(){
            $("#detail").attr("class","");
        });
        $("#close").click(function(){
            $("#detail").attr("class","hide");
        });
    </script>
</body>

</html>