<?php session_start(); ?>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../../css/admin.css">
    <script src="./js/jquery-3.4.1.js"></script>
</head>

<body>
    <?php
        if(isset($_SESSION["message"])){
    ?>
        <div id="message"><?=$_SESSION["message"]?></div>
    <?php
         unset($_SESSION["message"]);
    }
    ?>
    <?php
        function redirect($url)
        {
            header("Location: $url");
            exit();
        }
        if(!$_SESSION["login"]){
            redirect("../index.php");
        }
    ?>
    <?php
        try {
            $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
        $sql = "select * from employee;";
        $pdo->query('set names utf8;');
        $result = $pdo->query($sql);
        $rows = $result->fetchAll();
    ?>
    <table id="employee" class="showlist">
        <thead>
            <td class="id">编号</td>
            <td lass="name">姓名</td>
            <td class="tel">联系方式</td>
            <?php if($_SESSION["rank"] == 1){ ?>
            <td class="submit">&emsp;&emsp;</td>
            <?php } ?>
        </thead>
        <?php
        foreach ($rows as $row) {
        ?>
        <tr>
            <form action="../control/employee.php" method="POST">
                <td class="id"><input name="id" readonly="readonly" type="text" value="<?=$row["employeeNo"]?>"></td>
                <td class="name"><?=$row["employeeName"]?></td>
                <td class="tel"><input name="tel" type="text" value="<?=$row["telephone"]?>"></td>
                <?php if($_SESSION["rank"] == 1){ ?>
                <td class="submit">
                    <a href="../control/employee.php?delete=1&id=<?=$row["employeeNo"]?>">删除</a>
                    <input type="submit" value="提交">
                </td>
                <?php } ?>
            </form>
        </tr>
        <?php
        }
        ?>
        <tr class="hide">
            <form id="new" action="../control/employee.php" method="POST">
                <td class="id"><input name="id" type="text" value=""></td>
                <td class="name"><input name="name" type="text" value=""></td>
                <td class="tel"><input name="tel" type="text" value=""></td>
                <td class="com"><input name="com" type="text" value=""></td>
                <td class="rank"><input name="rank" type="number" value="" min="1" max="6"></td>
                <input type="hidden" name="add" value="1">
                <td><input type="submit" value="提交"></td>
            </form>
        </tr>
    </table>
    <?php if($_SESSION["rank"] == 1){ ?>
    <div id="add">
        <svg t="1577030058750" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
                p-id="1126" width="40" height="40">
            <path d="M912 262v500c0 41.3-14.7 76.7-44 106s-64.6 44-106 44H262.1c-41.3 0-76.7-14.7-106-44s-44-64.6-44-106V262c0-41.3 14.7-76.7 44-106s64.6-44 106-44h500c41.3 0 76.7 14.7 106 44 29.2 29.3 43.9 64.7 43.9 106zM778.6 545.4v-66.7c0-9-3.3-16.9-9.9-23.4-6.6-6.6-14.5-9.9-23.4-9.9H578.7V278.6c0-9-3.3-16.9-9.9-23.4-6.6-6.6-14.5-9.9-23.4-9.9h-66.7c-9 0-16.9 3.3-23.4 9.9s-9.9 14.5-9.9 23.4v166.6H278.7c-9 0-16.9 3.3-23.4 9.9-6.6 6.6-9.9 14.5-9.9 23.4v66.7c0 9 3.3 16.9 9.9 23.4 6.6 6.6 14.3 9.9 23.4 9.9h166.7v166.7c0 9 3.3 16.9 9.9 23.4 6.6 6.6 14.3 9.9 23.4 9.9h66.7c9 0 16.9-3.3 23.4-9.9 6.6-6.6 9.9-14.5 9.9-23.4V578.6h166.6c9 0 16.9-3.3 23.4-9.9 6.6-6.6 9.9-14.4 9.9-23.3z" p-id="1127" fill="#13227a"></path>
        </svg>
    </div>
    <script>
        $("#add").click(function(){
            $("tr.hide").attr("class","");
        });
        setTimeout(() => {
            $("#message").slideUp(1000);
        }, 1000);
    </script>
    <?php } ?>
</body>

</html>