<?php
session_start();
function redirect($url)
{
    header("Location: $url");
    exit();
}
if(!$_SESSION["login"]){
    redirect("../index.php");
}
try {
    $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}

if($_GET["delete"] == 1){
    $machine = $_GET["id"];
    $sql = "DELETE FROM vmachine WHERE vmachineno = '".$machine."';";
    $pdo->exec($sql);
}else{
    if($_POST["add"]){
        $id = $_POST["id"];
        $address = $_POST["address"];
        $manager = $_POST["manager"];
        $sql = "SELECT employeeNo FROM employee WHERE employeeName = '".$manager."';";
        $pdo->query('set names utf8;');
        $result = $pdo->query($sql);
        $rows = $result->fetchAll();
        $no = $rows[0]["employeeNo"];
        if($no){
            $sql = "INSERT INTO vmachine (VMachineNo, address) VALUES ('".$id."','".$address."');";
            $pdo->exec($sql);
            $sql = "INSERT INTO vmachineemploee (VMachineNo, employeeNo) VALUES ('".$id."','".$no."');";
            $pdo->exec($sql);
        }
    }else{
        $address = $_POST["address"];
        $machine = $_POST["id"];
        $sql = "UPDATE vmachine SET address = '".$address."' WHERE vmachineno = '".$machine."';";
        $pdo->exec($sql);
    }
}

redirect("../panel/machine.php");
?>