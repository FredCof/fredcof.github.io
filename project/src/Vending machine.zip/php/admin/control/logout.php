<?php
    session_start();
    function redirect($url)
    {
        header("Location: $url");
        exit();
    }
    $_SESSION["login"] = false;
    $_SESSION["rank"] = 200;
    redirect("../index.php");
?>