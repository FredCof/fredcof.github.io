<?php
session_start();
function redirect($url)
{
    header("Location: $url");
    exit();
}
if(!$_SESSION["login"]){
    redirect("../index.php");
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}

if($_GET["delete"]){
    $id = $_GET["id"];
    $sql = "DELETE FROM employee WHERE employeeno = '".$id."';";
    $pdo->exec($sql);
}else{
    if($_POST["add"]){
        $tel = $_POST["tel"];
        $id = $_POST["id"];
        $name = $_POST["name"];
        $com = $_POST["com"];
        $rank = $_POST["rank"];

        echo $_SESSION["rank"];
        echo $rank;
        if($_SESSION["rank"] >= intval($rank)){
            $_SESSION["message"] = "没有权限赋予更高级用户!!";
        }else{
        // echo $tel." ".$id." ".$name." ".$com." ".$rank;
            $sql = "INSERT INTO employee (employeeNo, employeeName, telephone, companyNo, powerNo, employeepassword) VALUES ('".$id."','".$name."','".$tel."','".$com."','".$rank."','123456');";
            $pdo->exec($sql);
        }
    }else{
        $tel = $_POST["tel"];
        $id = $_POST["id"];
        $sql = "UPDATE employee SET telephone = '".$tel."' WHERE employeeno = '".$id."';";
        $pdo->exec($sql);
    }
}

redirect("../panel/employee.php");
?>