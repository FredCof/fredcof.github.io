<?php session_start(); ?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../css/admin.css">
    <script src="../js/library/jquery-3.4.1.js"></script>
</head>

<body>
    <?php
    function redirect($url)
    {
        header("Location: $url");
        exit();
    }
    if(!$_SESSION["login"]){
        redirect("./index.php");
    }
    ?>
    <nav class="center">
        <div class="title">管理系统</div>
        <ul>
            <a href="./panel/machine.php" target="workspace" class="active">
                <li>贩卖机</li>
            </a>
            <a href="./panel/employee.php" target="workspace">
                <li>员工</li>
            </a>
            <?php if($_SESSION["rank"] == 1){ ?>
            <a href="./panel/supinfo.php" target="workspace">
                <li>供应单</li>
            </a>
            <a href="./panel/supshop.php" target="workspace">
                <li>供应商</li>
            </a>
            <a href="./panel/earn.php" target="workspace">
                <li>营业额</li>
            </a>
            <a href="./panel/store.php" target="workspace">
                <li>库存</li>
            </a>
            <?php } ?>
            <a href="./control/logout.php" style="float:right;">
                <li>退出登录</li>
            </a>
        </ul>
    </nav>
    <div class="container">
        <iframe src="./panel/machine.php" frameborder="0" id="workspace" name="workspace"></iframe>
    </div>

    <script type="text/javascript">
        $("nav a").click(function () {
            $(this).siblings().attr("class", "");
            $(this).attr("class", "active");
        });
    </script>

</body>

</html>