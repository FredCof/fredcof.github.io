<?php session_start(); ?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../css/login.css">
</head>

<body>
<?php
    function redirect($url)
    {
        header("Location: $url");
        exit();
    }
    if($_SESSION["login"]){
        redirect("./about.php");
    }
    ?>
    <form action="control/login.php" class="center" method="POST">
        <div>
            <label>工号</label><input name="id" type="text">
        </div>
        <div>
            <lable>密码</lable><input name="password" type="password">
        </div>
        <input type="submit">
    </form>
</body>

</html>