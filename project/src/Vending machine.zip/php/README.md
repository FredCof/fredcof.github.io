# 连接数据库

```php
try {
    $pdo = new PDO("mysql:host=localhost;dbname=onmyoji", "root", "123456");
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}
//执行sql语句
$sql = "select * from user";
$pdo->query('set names utf8;');
$result = $pdo->query($sql);
$rows = $result->fetchAll();
foreach ($rows as $row) {
    $id = $row["id"];
    $username = $row["name"];
    $pwd = $row["password"];
    echo $id." ".$username." ".$pwd."<br>";
}
```
