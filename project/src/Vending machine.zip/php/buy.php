<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css">
    <script src="./js/library/jquery-3.4.1.js"></script>
</head>

<body>
    <?php
        try {
            $pdo = new PDO("mysql:host=localhost;dbname=vmachine", "root", "123456");
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
    //执行sql语句
        $machine = $_GET["machine"];
        $product = $_GET["id"];

        $sql = "update productinvmachine set totalNum=totalNum-1 where productNo = ".$product." and VMachineNo = '".$machine."';";
        $pdo->exec($sql);
        $sql = "INSERT cpinfo (consumptionTime, VMachineNo, productNo) VALUES (now(),'".$machine."','".$product."');";
        $pdo->exec($sql);
    ?>
    <div class="succ center">
        <div class="info">
            <svg t="1576990170064" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
                p-id="9747" width="60" height="60">
                <path
                    d="M512 1024C229.243871 1024 0 794.756129 0 512 0 229.243871 229.243871 0 512 0c282.756129 0 512 229.243871 512 512 0 282.756129-229.243871 512-512 512z m-38.631226-291.674839l388.541936-396.420129a31.744 31.744 0 0 0-0.72671-45.254193 32.635871 32.635871 0 0 0-45.749677 0.726709l-363.354839 338.910968-215.188645-157.431742a32.635871 32.635871 0 0 0-45.733162 1.899355 31.744 31.744 0 0 0 1.932388 45.204645l235.140129 213.636129c12.915613 11.726452 32.933161 11.164903 45.13858-1.288258z"
                    p-id="9748"></path>
            </svg>
            <div>购买成功</div>
        </div>
    </div>
    <script>
        setTimeout(() => {
            $(window).attr('location','./index.php');
        }, 1000);
    </script>
</body>

</html>